import string
import random
from typing import List, Callable
from abc import ABC, abstractmethod

class SupportTicket:
    id: str
    customer: str
    issue: str

    def __init__(self, customer, issue):
        self.id = generate_id()
        self.customer = customer
        self.issue = issue

def generate_id(length=8):
    # helper function for generating an id
    return ''.join(random.choices(string.ascii_uppercase, k=length))

def fifo_ordering(list: List[SupportTicket]) -> List[SupportTicket]:
    return list.copy()


def filo_ordering(list: List[SupportTicket]) -> List[SupportTicket]:
    list_copy = list.copy()
    list_copy.reverse()
    return list.copy


def random_ordering(list: List[SupportTicket]) -> List[SupportTicket]:
    list_copy = list.copy()
    random.shuffle(list_copy)
    return list.copy

def black_hole_ordering(list: List[SupportTicket]) -> List[SupportTicket]:
    return []

class CustomerSupport:

    tickets: List[SupportTicket] = []

    def create_ticket(self, customer, issue):
        self.tickets.append(SupportTicket(customer, issue))


    def process_ticket(self, processing_strategy_fn: Callable[[List[SupportTicket]], List[SupportTicket]]):

        # create the ordered list
        ticket_list = processing_strategy_fn(self.tickets)

        # if it's empty, don't do anything
        if len(self.tickets) == 0:
            print("There are no tickets to process. Well done !")
            return

        

        for ticket in self.tickets:
            self.process_ticket(ticket)

        def process_ticket(self, ticket: SupportTicket):
            print("=============================")
            print(f"Processing ticket id: {ticket.id}")
            print(f"Customer: {ticket.customer}")
            print(f"Issue: {ticket.issue}")
            print("=============================")
            

# create the application
app = CustomerSupport()

# register a few tickets
app.create_ticket("John Smith", "My computer makes strange noise")
app.create_ticket("Linus Sebastian", "I can't upload any video, please help")
app.create_ticket("Arjan Egger", "VSCode doesn't automatically solve my bug")

# process the tickets
app.process_ticket(fifo_ordering)

